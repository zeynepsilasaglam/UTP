package eu.glowacki.utp.assignment04;

import java.util.Date;

public final class Person implements Comparable<Person> {
	
	private final String firstName;
	private final String surname;
	private final Date birthdate;
	
	public Person(String firstName, String surname, Date birthdate) {
		this.firstName = firstName;
		this.surname = surname;
		this.birthdate = birthdate;
	}


	public String getFirstName() {
		return firstName;
	}

	public String getSurname() {
		return surname;
	}

	public Date getBirthdate() {
		return birthdate;
	}

	@Override
	public String toString() {
		return
				firstName + " " +
				 surname + " " +
				 birthdate;
	}

	@Override
	public int compareTo(Person otherPerson) {

		//1)surname
		//2)firstname
		//3)birthdate
		int res;
		res= this.getSurname().compareTo(otherPerson.getSurname());
		if (res != 0)
			return res;

		res = this.getFirstName().compareTo(otherPerson.getSurname());
		if (res != 0)
			return res;

		return this.getBirthdate().compareTo(otherPerson.getBirthdate());

	}
}