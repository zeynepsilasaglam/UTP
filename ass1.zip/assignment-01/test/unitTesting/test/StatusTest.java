package unitTesting.test;

import eu.glowacki.utp.assignment01.Status;
import eu.glowacki.utp.assignment01.User;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class StatusTest {

        private static final String statusHello = "Hello world";

        private Status status;

        @Before
        public void before() {
            status = new Status(statusHello);
            Assert.assertEquals(statusHello, status.getStatus());
        }

        @Test
        public void aggregate() {
            String aggregate = status.aggregate(null);
            System.out.println(aggregate);
            Assert.assertEquals(statusHello, aggregate);
            final String init = "Hello world";
            Assert.assertEquals((String) (statusHello + init), (String) (status.aggregate(init)));
        }

        @Test
        public void deepClone() {
            Status clone = status.deepClone();
            Assert.assertEquals(status.getStatus(), clone.getStatus());
            Assert.assertNotSame(statusHello, clone);
        }
    }


