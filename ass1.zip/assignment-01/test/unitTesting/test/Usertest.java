package unitTesting.test;

import eu.glowacki.utp.assignment01.User;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
public class Usertest {




        private static final int id = 22142;

        private User user;

        @Before
        public void before() {
            user = new User(id);
            Assert.assertEquals(id, user.getId());
        }

        @Test
        public void aggregate() {
            int aggregate = user.aggregate(null);
            System.out.println(aggregate);
            Assert.assertEquals(id, aggregate);
            final int init = 22142;
            Assert.assertEquals((int) (id + init), (int) (user.aggregate(init)));
        }

        @Test
        public void deepClone() {
            User clone = user.deepClone();
            Assert.assertEquals(user.getId(), clone.getId());
            Assert.assertNotSame(user, clone);
        }
    }

