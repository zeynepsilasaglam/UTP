package unitTesting.test;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import eu.glowacki.utp.assignment01.User;
import eu.glowacki.utp.assignment01.ContainerClass;
import eu.glowacki.utp.assignment01.Status;

public class MyContainerTest {
	private ContainerClass<User, Integer> users;
	private ContainerClass<Status, String> statuses;
	private User Zeynep;
	private User Jalil;
	private Status status1;
	private Status status2;
	private ArrayList<User> userArrayList;
	private ArrayList<Status> statusArrayList;
	
	@Before
	public void setUp() {
		// defining class instances
		users = new ContainerClass<>();
		Zeynep = null;
		Jalil = null;
		userArrayList = new ArrayList<>();
		statuses = new ContainerClass<>();
		status1 = new Status("firstStatus");
		status2 = new Status("secondStatus");
		
	}

	@Test
	public void testElements() { 
		Assert.assertEquals(userArrayList, users.elements());
	}
	
	@Test
	public void testAggregateAllElements() {
		
		statusArrayList = (ArrayList<Status>) statuses.elements();
		statusArrayList.add(status1);
		statusArrayList.add(status2);
		userArrayList = (ArrayList<User>) users.elements();
		userArrayList.add(Zeynep);
		userArrayList.add(Jalil);
		Assert.assertEquals(null, users.aggregateAllElements());
		Assert.assertEquals("firstStatussecondStatus", statuses.aggregateAllElements());
	}
	
	
	@Test
	public void testCloneElementAtIndex() {
		userArrayList = (ArrayList<User>) users.elements();
		userArrayList.add(Zeynep);
		userArrayList.add(Jalil);
		Assert.assertNull(users.cloneElementAtIndex(2));
	}
	
}