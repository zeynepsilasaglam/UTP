package eu.glowacki.utp.assignment01;

import java.util.ArrayList;
import java.util.List;

public class ContainerClass <Stype extends IAggregable<Stype, Rtype> & IDeeplyCloneable<Stype>, Rtype> implements IContainer<Stype, Rtype> {

	private final ArrayList<Stype> container;

	public ContainerClass() {
		container = new ArrayList<>();
	}

	@Override
	public List<Stype> elements() {
		return container;
	}

	@Override
	public Rtype aggregateAllElements() {
		Rtype result = null;
		for (Stype element : container) {
			result = element.aggregate(result);
		}
		return result;
	}

	@Override
	public Stype cloneElementAtIndex(int index) {
		if (index < 0 || index >= container.size()) {
			return null;
		}
		return container.get(index).deepClone();
	}
}
