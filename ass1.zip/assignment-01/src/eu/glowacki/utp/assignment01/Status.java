package eu.glowacki.utp.assignment01;

public class Status implements IAggregable<Status, String>, IDeeplyCloneable<Status>{


	private String userstatus;
	public String getStatus() {
		return userstatus;
	}
	
	
	public Status(String stringArg) {
		this.userstatus = stringArg;
	}

	@Override
	public Status deepClone() {
		Status clone = new Status(this.userstatus);
		return clone;
	}

	@Override
	public String aggregate(String intermediateResult) {
		if(intermediateResult == null)
			return userstatus;
		else return  intermediateResult + userstatus;
	}

	@Override
	public String printResult() {
		return userstatus;
	}

	@Override
	public String toString() {
		return "Status is '" + userstatus + "'" ;
	}
	

}
