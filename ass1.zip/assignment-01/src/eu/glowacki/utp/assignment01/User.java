package eu.glowacki.utp.assignment01;

public class User implements IAggregable<User, Integer>, IDeeplyCloneable<User> {

	private int id;
	
	public User(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}

	@Override
	public Integer aggregate(Integer intermediateResult) {
		if (intermediateResult == null) {
			return id;
		} else
			return id + intermediateResult;
	}
	
	@Override
	public Integer printResult() {
		return id;
	}
	
	@Override
	public User deepClone() {
		User user = new User(this.id);
		return user;

	}

	@Override
	public String toString() {
		return "User's id number: " + id;
	}
	
}