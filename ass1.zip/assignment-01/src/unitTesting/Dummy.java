package unitTesting;

public class Dummy {

	public int returnsOne() {
		return 1;
	}
}