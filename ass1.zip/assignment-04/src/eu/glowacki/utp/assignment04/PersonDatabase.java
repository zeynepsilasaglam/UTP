package eu.glowacki.utp.assignment04;

import eu.glowacki.utp.assignment04.comparators.FirstNameComparator;
import eu.glowacki.utp.assignment04.comparators.BirthdateComparator;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;


public final class PersonDatabase {

	private static final Comparator<Person> BY_FULLINFO = Comparator.naturalOrder();
	private static final Comparator<Person> BY_NAME = new FirstNameComparator();
	private static final Comparator<Person> BY_DATE = new BirthdateComparator();


	private final List<Person> fullinfo;
	private final List<Person> date;
	private final List<Person> name;
	private final Map<Date, List<Person>> searchByDate;

	public PersonDatabase(File file) throws IOException, ParseException {
		this(InputParser.parse(file));
	}

	public PersonDatabase(List<Person> data) {
		fullinfo = data;
		fullinfo.sort(BY_FULLINFO);

		name = new ArrayList<>(data);
		name.sort(BY_NAME);

		date = new ArrayList<>(data);
		date.sort(BY_DATE);

		searchByDate = data.stream().collect(Collectors.groupingBy(Person::getBirthdate, TreeMap::new,
				Collectors.mapping(p -> p, Collectors.toList())));
	}

	public List<Person> sortedByFirstName() {
		return name; // external rule for ordering (based on Comparator --- FirstNameComparator)
	}
	
	public List<Person> sortedBySurnameFirstNameAndBirthdate() {
		return fullinfo; // natural order (Comparable)
	}
	
	public List<Person> sortedByBirthdate() {
		return date; // external rule for ordering (based on Comparator --- BirthdateComparator)
	}
	
	public List<Person> bornOnDay(Date date) {
		return searchByDate.get(date);
	}

	public int size_fullinfo(){
		return fullinfo.size();
	}
}
