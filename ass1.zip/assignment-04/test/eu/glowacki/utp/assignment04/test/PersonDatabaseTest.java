package eu.glowacki.utp.assignment04.test;

import eu.glowacki.utp.assignment04.PersonDatabase;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PersonDatabaseTest {
    private static final DateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
    private static File file = new File("src/eu/glowacki/utp/assignment04/Data.txt");
    PersonDatabase check;
    Date input;

    public void Before() throws Exception {
        input = dateformat.parse("1988-05-25");
    }


    @Test
    public void testPersonDatabaseListOfPerson() throws ParseException, IOException {

        check = new PersonDatabase(file);
        Assert.assertEquals(25, check.size_fullinfo());
    }

    @Test
    public void sortedTest() throws Exception {

        check = new PersonDatabase(file);
        Assert.assertEquals(check.sortedByFirstName().get(24).getFirstName(), "Tracey");
        Assert.assertEquals(check.sortedByBirthdate().get(0).getFirstName(), "Sherry");
        Assert.assertEquals(check.sortedBySurnameFirstNameAndBirthdate().get(24).getFirstName(), "Simon");

    }
}